import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppItem, User, Review } from '../types';
import { fallbackApps } from '../data/fallbackApps';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  collection, 
  getDocs, 
  query, 
  orderBy
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import firebaseConfig from '../../firebase-applet-config.json';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface StoreContextType {
  currentUser: User | null;
  apps: AppItem[];
  loginWithPassword: (username: string, password: string) => Promise<void>;
  signUpWithPassword: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  becomeDeveloper: () => Promise<void>;
  publishApp: (app: Omit<AppItem, 'id' | 'rating' | 'reviews' | 'downloads' | 'createdAt'>) => Promise<void>;
  addReview: (appId: string, review: Omit<Review, 'id' | 'date'>) => Promise<void>;
  getAppById: (id: string) => AppItem | undefined;
  getReviewsForApp: (appId: string) => Review[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  // Installation & Pinning APIs
  installedAppIds: string[];
  pinnedAppIds: string[];
  installApp: (appId: string) => void;
  uninstallApp: (appId: string) => void;
  pinApp: (appId: string) => void;
  unpinApp: (appId: string) => void;
  incrementDownloads: (appId: string) => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [apps, setApps] = useState<AppItem[]>([]);
  const [reviewsMap, setReviewsMap] = useState<Record<string, Review[]>>({});
  const [authReady, setAuthReady] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Real installations state
  const [installedAppIds, setInstalledAppIds] = useState<string[]>([]);
  const [pinnedAppIds, setPinnedAppIds] = useState<string[]>([]);

  useEffect(() => {
    const savedInstalls = localStorage.getItem('installed_apps_v2');
    if (savedInstalls) {
      try {
        setInstalledAppIds(JSON.parse(savedInstalls));
      } catch (e) {
        console.error(e);
      }
    }
    const savedPins = localStorage.getItem('pinned_apps_v2');
    if (savedPins) {
      try {
        setPinnedAppIds(JSON.parse(savedPins));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const installApp = (appId: string) => {
    setInstalledAppIds(prev => {
      if (prev.includes(appId)) return prev;
      const updated = [...prev, appId];
      localStorage.setItem('installed_apps_v2', JSON.stringify(updated));
      return updated;
    });
  };

  const uninstallApp = (appId: string) => {
    setInstalledAppIds(prev => {
      const updated = prev.filter(id => id !== appId);
      localStorage.setItem('installed_apps_v2', JSON.stringify(updated));
      return updated;
    });
    setPinnedAppIds(prev => {
      const updated = prev.filter(id => id !== appId);
      localStorage.setItem('pinned_apps_v2', JSON.stringify(updated));
      return updated;
    });
  };

  const pinApp = (appId: string) => {
    setPinnedAppIds(prev => {
      if (prev.includes(appId)) return prev;
      const updated = [...prev, appId];
      localStorage.setItem('pinned_apps_v2', JSON.stringify(updated));
      return updated;
    });
  };

  const unpinApp = (appId: string) => {
    setPinnedAppIds(prev => {
      const updated = prev.filter(id => id !== appId);
      localStorage.setItem('pinned_apps_v2', JSON.stringify(updated));
      return updated;
    });
  };

  useEffect(() => {
    // Check local session first
    const savedLocalUser = localStorage.getItem('local_logged_in_user_v1');
    if (savedLocalUser) {
      try {
        setCurrentUser(JSON.parse(savedLocalUser));
      } catch (err) {
        console.error('Error parsing local user:', err);
      }
      setAuthReady(true);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        await fetchAndSetUser(user);
      } else {
        const locallyLogged = localStorage.getItem('local_logged_in_user_v1');
        if (!locallyLogged) {
          setCurrentUser(null);
        }
        setAuthReady(true);
      }
    });
    
    return () => unsubscribe();
  }, []);

  const fetchAndSetUser = async (authUser: FirebaseUser) => {
    const path = `users/${authUser.uid}`;
    try {
      const docRef = doc(db, 'users', authUser.uid);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        const newUser: User = {
          id: authUser.uid,
          name: authUser.displayName || authUser.email?.split('@')[0] || 'User',
          isDeveloper: false,
        };
        const createData = {
          ...newUser,
          createdAt: Date.now()
        };
        try {
          await setDoc(docRef, createData);
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
        setCurrentUser(newUser);
      } else {
        const data = docSnap.data();
        setCurrentUser({
          id: authUser.uid,
          name: data.name || 'User',
          isDeveloper: data.isDeveloper || false
        } as User);
      }
    } catch (err) {
      console.error('Error fetching/setting user:', err);
    } finally {
      setAuthReady(true);
    }
  };

  const fetchApps = async () => {
    const path = 'apps';
    try {
      const q = query(collection(db, 'apps'));
      const querySnapshot = await getDocs(q);
      const dbAppsList: AppItem[] = [];
      querySnapshot.forEach((doc) => {
        const d = doc.data();
        dbAppsList.push({
          id: doc.id,
          name: d.name,
          developerId: d.developerId,
          developerName: d.developerName,
          description: d.description,
          category: d.category,
          iconDataUrl: d.iconDataUrl,
          fileObjectUrl: d.fileObjectUrl,
          fileName: d.fileName,
          rating: d.rating || 0,
          reviews: [],
          downloads: d.downloads || 0,
          size: d.size || '0 MB',
          version: d.version || '1.0.0',
          createdAt: d.createdAt
        });
      });

      const localSaved = localStorage.getItem('local_published_apps_v1');
      const localAppsList: AppItem[] = localSaved ? JSON.parse(localSaved) : [];
      
      const mergedMap = new Map<string, AppItem>();
      
      fallbackApps.forEach(item => mergedMap.set(item.id, item));
      localAppsList.forEach(item => mergedMap.set(item.id, item));
      dbAppsList.forEach(item => mergedMap.set(item.id, item));
      
      const sortedApps = Array.from(mergedMap.values())
        .filter(app => !app.id.startsWith('premium-app-') && !app.id.startsWith('mock-'))
        .sort((a, b) => {
          const timeA = typeof a.createdAt === 'number' ? a.createdAt : new Date(a.createdAt).getTime();
          const timeB = typeof b.createdAt === 'number' ? b.createdAt : new Date(b.createdAt).getTime();
          return (timeB || 0) - (timeA || 0);
        });
      
      setApps(sortedApps);
    } catch (err) {
      console.warn('Firestore fetchApps failed, using local fallback:', err);
      
      const localSaved = localStorage.getItem('local_published_apps_v1');
      const localAppsList: AppItem[] = localSaved ? JSON.parse(localSaved) : [];
      const mergedMap = new Map<string, AppItem>();
      fallbackApps.forEach(item => mergedMap.set(item.id, item));
      localAppsList.forEach(item => mergedMap.set(item.id, item));
      
      const filtered = Array.from(mergedMap.values())
        .filter(app => !app.id.startsWith('premium-app-') && !app.id.startsWith('mock-'));
      setApps(filtered);
    }
  };

  useEffect(() => {
    if (!authReady) return;
    fetchApps();
    
    const interval = setInterval(fetchApps, 15000);
    return () => clearInterval(interval);
  }, [authReady]);

  const fetchReviews = async (appId: string) => {
    const path = `apps/${appId}/reviews`;
    try {
      const q = query(collection(db, 'apps', appId, 'reviews'));
      const querySnapshot = await getDocs(q);
      const dbReviewsList: Review[] = [];
      querySnapshot.forEach((doc) => {
        const rData = doc.data();
        dbReviewsList.push({
          id: doc.id,
          userName: rData.userName,
          rating: rData.rating,
          text: rData.text,
          date: rData.date
        });
      });

      const fbApp = fallbackApps.find(a => a.id === appId);
      const fbReviews = fbApp ? fbApp.reviews : [];
      
      const localRevSaved = localStorage.getItem('local_reviews_map_v1');
      const localMap = localRevSaved ? JSON.parse(localRevSaved) : {};
      const localReviewsList = localMap[appId] || [];
      
      const mergedReviewsMap = new Map<string, Review>();
      fbReviews.forEach(r => mergedReviewsMap.set(r.id, r));
      localReviewsList.forEach((r: Review) => mergedReviewsMap.set(r.id, r));
      dbReviewsList.forEach(r => mergedReviewsMap.set(r.id, r));
      
      const sortedReviews = Array.from(mergedReviewsMap.values()).sort((a, b) => {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });
      
      setReviewsMap(prev => ({ ...prev, [appId]: sortedReviews }));
    } catch (err) {
      console.warn(`Firestore fetchReviews failed for appId ${appId}:`, err);
      const fbApp = fallbackApps.find(a => a.id === appId);
      const fbReviews = fbApp ? fbApp.reviews : [];
      const localRevSaved = localStorage.getItem('local_reviews_map_v1');
      const localMap = localRevSaved ? JSON.parse(localRevSaved) : {};
      const localReviewsList = localMap[appId] || [];
      
      const mergedReviewsMap = new Map<string, Review>();
      fbReviews.forEach(r => mergedReviewsMap.set(r.id, r));
      localReviewsList.forEach((r: Review) => mergedReviewsMap.set(r.id, r));
      
      setReviewsMap(prev => ({ ...prev, [appId]: Array.from(mergedReviewsMap.values()) }));
    }
  };

  useEffect(() => {
    apps.forEach(app => {
      if (!reviewsMap[app.id]) {
        fetchReviews(app.id);
      }
    });
  }, [apps]);

  const getEmail = (username: string) => {
    const clean = username.trim().toLowerCase();
    return clean.includes('@') ? clean : `${clean}@marketplace.local`;
  };

  const loginWithPassword = async (username: string, password: string) => {
    const email = getEmail(username);
    const isPlaceholder = !firebaseConfig.projectId || firebaseConfig.projectId.includes('placeholder');
    
    if (isPlaceholder) {
      // Direct local login
      const localUsersSaved = localStorage.getItem('local_users_db_v1');
      const localUsers: Record<string, { username: string; passwordHash: string; id: string; isDeveloper: boolean }> = localUsersSaved 
        ? JSON.parse(localUsersSaved) 
        : {};
      
      const key = username.trim().toLowerCase();
      const userRecord = localUsers[key];
      
      if (!userRecord || userRecord.passwordHash !== password) {
        throw new Error('Usuário ou senha incorretos.');
      }
      
      const loggedUser: User = {
        id: userRecord.id,
        name: userRecord.username,
        isDeveloper: userRecord.isDeveloper || false
      };
      
      localStorage.setItem('local_logged_in_user_v1', JSON.stringify(loggedUser));
      setCurrentUser(loggedUser);
      return;
    }

    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      // Local login fallback
      const localUsersSaved = localStorage.getItem('local_users_db_v1');
      const localUsers: Record<string, { username: string; passwordHash: string; id: string; isDeveloper: boolean }> = localUsersSaved 
        ? JSON.parse(localUsersSaved) 
        : {};
      
      const key = username.trim().toLowerCase();
      const userRecord = localUsers[key];
      
      if (userRecord && userRecord.passwordHash === password) {
        const loggedUser: User = {
          id: userRecord.id,
          name: userRecord.username,
          isDeveloper: userRecord.isDeveloper || false
        };
        localStorage.setItem('local_logged_in_user_v1', JSON.stringify(loggedUser));
        setCurrentUser(loggedUser);
        return;
      }
      throw err;
    }
  };

  const signUpWithPassword = async (username: string, password: string) => {
    const email = getEmail(username);
    const isPlaceholder = !firebaseConfig.projectId || firebaseConfig.projectId.includes('placeholder');

    if (isPlaceholder) {
      const localUsersSaved = localStorage.getItem('local_users_db_v1');
      const localUsers: Record<string, { username: string; passwordHash: string; id: string; isDeveloper: boolean }> = localUsersSaved 
        ? JSON.parse(localUsersSaved) 
        : {};
      
      const key = username.trim().toLowerCase();
      if (localUsers[key]) {
        throw new Error('Este nome de usuário já está sendo utilizado.');
      }
      
      const userId = 'local-user-' + crypto.randomUUID();
      const newUserRecord = {
        username: username.trim(),
        passwordHash: password,
        id: userId,
        isDeveloper: false
      };
      
      localUsers[key] = newUserRecord;
      localStorage.setItem('local_users_db_v1', JSON.stringify(localUsers));
      
      const loggedUser: User = {
        id: userId,
        name: username.trim(),
        isDeveloper: false
      };
      localStorage.setItem('local_logged_in_user_v1', JSON.stringify(loggedUser));
      setCurrentUser(loggedUser);
      return;
    }

    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      // Local fallback registration
      const localUsersSaved = localStorage.getItem('local_users_db_v1');
      const localUsers: Record<string, { username: string; passwordHash: string; id: string; isDeveloper: boolean }> = localUsersSaved 
        ? JSON.parse(localUsersSaved) 
        : {};
      
      const key = username.trim().toLowerCase();
      if (localUsers[key]) {
        throw new Error('Este nome de usuário já está sendo utilizado.');
      }
      
      const userId = 'local-user-' + crypto.randomUUID();
      const newUserRecord = {
        username: username.trim(),
        passwordHash: password,
        id: userId,
        isDeveloper: false
      };
      
      localUsers[key] = newUserRecord;
      localStorage.setItem('local_users_db_v1', JSON.stringify(localUsers));
      
      const loggedUser: User = {
        id: userId,
        name: username.trim(),
        isDeveloper: false
      };
      localStorage.setItem('local_logged_in_user_v1', JSON.stringify(loggedUser));
      setCurrentUser(loggedUser);
    }
  };

  const logout = async () => {
    localStorage.removeItem('local_logged_in_user_v1');
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Firebase logout skipped or failed:', e);
    }
    setCurrentUser(null);
  };

  const becomeDeveloper = async () => {
    if (currentUser) {
      if (currentUser.id.startsWith('local-user-')) {
        const localUsersSaved = localStorage.getItem('local_users_db_v1');
        if (localUsersSaved) {
          try {
            const localUsers = JSON.parse(localUsersSaved);
            const key = currentUser.name.toLowerCase();
            if (localUsers[key]) {
              localUsers[key].isDeveloper = true;
              localStorage.setItem('local_users_db_v1', JSON.stringify(localUsers));
            }
          } catch (e) {
            console.error(e);
          }
        }
        const updatedUser = { ...currentUser, isDeveloper: true };
        localStorage.setItem('local_logged_in_user_v1', JSON.stringify(updatedUser));
        setCurrentUser(updatedUser);
        return;
      }

      const path = `users/${currentUser.id}`;
      try {
        const docRef = doc(db, 'users', currentUser.id);
        await updateDoc(docRef, { isDeveloper: true });
        setCurrentUser({ ...currentUser, isDeveloper: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const publishApp = async (newAppInfo: Omit<AppItem, 'id' | 'rating' | 'reviews' | 'downloads' | 'createdAt'>) => {
    const appUid = crypto.randomUUID();
    const newApp: AppItem = {
      ...newAppInfo,
      id: appUid,
      rating: 0,
      reviews: [],
      downloads: 0,
      createdAt: Date.now() // Timestamps must be numeric for our firestore rule validations
    };
    
    try {
      const localSaved = localStorage.getItem('local_published_apps_v1');
      const localAppsList = localSaved ? JSON.parse(localSaved) : [];
      localAppsList.push(newApp);
      localStorage.setItem('local_published_apps_v1', JSON.stringify(localAppsList));
    } catch (e) {
      console.error('Failed saving to localStorage backup:', e);
    }

    const path = `apps/${appUid}`;
    try {
      const docRef = doc(db, 'apps', appUid);
      // Omit reviews field to strictly match entity config keys in firestore.rules
      const { reviews, ...firebaseAppObj } = newApp;
      await setDoc(docRef, {
        ...firebaseAppObj,
        reviewCount: 0
      });
    } catch (err) {
      console.warn('Firestore publish failed, relying on localStorage:', err);
      handleFirestoreError(err, OperationType.CREATE, path);
    }
    
    await fetchApps();
  };

  const addReview = async (appId: string, reviewInfo: Omit<Review, 'id' | 'date'>) => {
    const rId = crypto.randomUUID();
    const newReview: Review = {
      ...reviewInfo,
      id: rId,
      date: new Date().toISOString()
    };

    try {
      const localRevSaved = localStorage.getItem('local_reviews_map_v1');
      const localMap = localRevSaved ? JSON.parse(localRevSaved) : {};
      if (!localMap[appId]) localMap[appId] = [];
      localMap[appId].push(newReview);
      localStorage.setItem('local_reviews_map_v1', JSON.stringify(localMap));
    } catch (e) {
      console.error('Failed saving review to localStorage:', e);
    }

    const path = `apps/${appId}/reviews/${rId}`;
    try {
      const reviewDocRef = doc(db, 'apps', appId, 'reviews', rId);
      // In Firestore, the Review schema is exactly: ["userId", "userName", "rating", "text", "date"] (size: 5)
      // Omit review ID inside document, as it is contained in the document's path variables!
      await setDoc(reviewDocRef, {
        userId: currentUser?.id || 'anonymous',
        userName: reviewInfo.userName,
        rating: reviewInfo.rating,
        text: reviewInfo.text,
        date: newReview.date
      });
      
      const app = getAppById(appId);
      if (app) {
        const curCount = (app as any).reviewCount || 0;
        const curRating = app.rating || 0;
        const newCount = curCount + 1;
        const newRating = ((curRating * curCount) + reviewInfo.rating) / newCount;
        
        const pathApp = `apps/${appId}`;
        try {
          const appDocRef = doc(db, 'apps', appId);
          await updateDoc(appDocRef, { rating: newRating, reviewCount: newCount });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, pathApp);
        }
      }
    } catch (err) {
      console.warn('Firestore review failed, relying on localStorage:', err);
      handleFirestoreError(err, OperationType.CREATE, path);
    }

    await fetchApps();
    await fetchReviews(appId);
  };

  const incrementDownloads = async (appId: string) => {
    setApps(prev => prev.map(app => {
      if (app.id === appId) {
        return { ...app, downloads: (app.downloads || 0) + 1 };
      }
      return app;
    }));

    const path = `apps/${appId}`;
    try {
      const docRef = doc(db, 'apps', appId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const currentDownloads = docSnap.data().downloads || 0;
        await updateDoc(docRef, { downloads: currentDownloads + 1 });
      }
    } catch (err) {
      console.warn('Firestore incrementDownloads failed:', err);
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const getAppById = (id: string) => apps.find(a => a.id === id);
  const getReviewsForApp = (id: string) => reviewsMap[id] || [];

  return (
    <StoreContext.Provider value={{
      currentUser,
      apps,
      loginWithPassword,
      signUpWithPassword,
      logout,
      becomeDeveloper,
      publishApp,
      addReview,
      getAppById,
      getReviewsForApp,
      searchQuery,
      setSearchQuery,
      installedAppIds,
      pinnedAppIds,
      installApp,
      uninstallApp,
      pinApp,
      unpinApp,
      incrementDownloads
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
